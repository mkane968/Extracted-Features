#@ PackageList
install.packages("beepr")             #beeps!
#install.packages(c("RCurl", "XML"))   #XML stuff
#install.packages(c("dplyr", "ggplot2"))
#install.packages("githubinstall")
#install.packages("stringr")
### githubinstall("htmlToText") ### appear to be multiple packages named this

library(beepr)
#library(RCurl)
#library(XML)
#library(dplyr)
#library(ggplot2)
#library(githubinstall)
#library(stringr)




######################################################################
#Library R Work-File updated 3/6/2019         ## Converting data
##### clean your workspace        __ rm(list=ls())
#


########################################################################
########################################################################
############ The Functions!
########################################################################
############ Be sure to run the ones you want, before you start
########################################################################
#
#
########################################################################
#### THIS is a function to create a matrix of file names and #s   ######
########################################################################
list.m <- matrix(NA, 0, 2)
list.files <- function(names){
  for (i in 1:length(files.v)){
    v <- c(i, files.v[i])
    list.m <- rbind(list.m, v)
  }
  return(list.m)
}


########################################################################
##########   The most important function: READ THE TEXTS!  #############
########################################################################
##### this function takes a vector of filenames and a directory path ###
###    and returns a list of each item in the list as ordered words ####
########################################################################

make.file.word.v.l <- function(files.v, input.dir){
  text.word.vector.l <- list()
  for(i in 1:length(files.v)){
    #@ read the files in the directory
    text.v <- scan(paste(input.dir, files.v[i], sep="/"), what="character", sep="\n")
    #@ convert to a single string
    text.v <- paste(text.v, collapse=" ")
    #@ we're making it one big line here - then taking it to lowercase, split on nonword chars
          #@text.lower.v <- tolower(text.v)                ## we do NOT want to 'tolower' this yet,
          #@text.words.v <- strsplit(text.lower.v, "\\W")  ## because we need uppercase 'CHAPTER's
    text.words.v <- strsplit(text.v, "\\W")
    #@ "\\W" finds everything that is a word
    text.words.v <- unlist(text.words.v)
    text.words.v <- text.words.v[which(text.words.v!="")]
    #@ use index id as name of list
    text.word.vector.l[[files.v[i]]] <- text.words.v
  }
  return(text.word.vector.l)}




########################################################################
########################################################################
############ The Code Itself begins here:
########################################################################
#
#
########################################################################
############ Set your working directory (the default is for this code ##
############ to work automatically when the folder is in your desktop ##
########################################################################

###### Run the code as-is from your desktop, OR change the directory object to point to the 
###### location of the "SciFiPipeline" folder (replace 'Desktop' below as appropriate)
## making a 'directory' object so that the directory can be reset to original location later
proj.dir <- "~/Desktop/SciFiPipeline/"  
setwd(proj.dir)
#dir.create("newFolder")  ## to create new folders


########################################################################
############       LOADING IN RAW DATA                    ##############
########################################################################

# your input directory is the location of the raw data, starting from 
# your working directory

input.dir <- "sfdata/"
files.v <- dir(input.dir, "\\.txt$")
files.v
####@ ** optional **   PICK JUST A FEW FILES instead of EVERY file
###       _   files.v <- files.v[c(2: 3)] ; files.v    




########## Create a matrix of positions, names, (TBD: other data? source?)
#file.list.v <- list.files(files.v)
#file.list.v
###### as of now, this (and this function) are unnecessary
###### however, this would be the way to store metadata about the corpus, which
###### could be added back to cleaned/processed output data later


################# the 'my.corpus.l' object is what contains THE TEXTS THEMSELVES
my.corpus.l <- make.file.word.v.l(files.v, input.dir)
beep("complete")
#
my.corpus.l[[1]][1:20]


######### this loop removes .txt from file names (must do this AFTER reading data files)
for(book in 1:length(files.v)){
  files.v[book] <- gsub('.{4}$', '', files.v[book])}
files.v




########################################################################
####### Begin the proper DATA CLEANING       ###########################
########################################################################
##########Starting with identifying instances of  "CHAPTER"   ##########
########################################################################


CH_inst.v <- c(1:200)   #@ expected greatest # of chapters/book (no harm over-shooting this)  
files.v                 #@ your vector of file names 
#  (note that the files appear in your corpus in the same order
#   so files.v will point to correct locations in your corpus)
CH_inst.a <- array(NA, dim=c(length(files.v), length(CH_inst.v)), dimnames=list(files.v, CH_inst.v))
#CH_inst.a[1:5,1:5]     #@ this is a matrix which will be used to store instances of CHAPTER in each book  

#### actually Fill In the positions of each instance of a "CHAPTER" token
for (book in 1:length(files.v)){
  beep("coin")  # you get a beep for each book as the loop starts on it
  for (inst in 1:length(CH_inst.v)){
    holder <- which(my.corpus.l[[book]][] == "CHAPTER")
    CH_inst.a[book, 1:length(holder)] <- holder
  }
  print(paste(length(holder), "instances of CHAPTER in", files.v[book]))
}
beep("complete")
CH_inst.a[,1:10]                 



########################################################################
########################################################################
############################# isolate CONSUMABLE CHAPTER contents  #####
####### here we are "chunking out" the chapters based on the above #####
########################################################################

CH_id.v <- c("book", "ch#", "CHtext") #@ the header for data being stored
CH_inst.v  #@ (re-using this object from above) - expected greatest # chapters/book
files.v    #@ (re-using this object again) -- the vector of book titles
chapters.a <- array(NA, 
                    dim=c(length(CH_id.v), length(CH_inst.v), length(files.v)),
                    dimnames=list(CH_id.v, CH_inst.v, files.v))

#@ remember, CH_inst.a (array data object created above) 
#@ holds the positon of each "CHAPTER" token from each book



########## This multi-loop command determines (for each chapter within each book)
########## the start and end points of each chapter
########## and then isolates and stores the contents of each chapter
for(book in 1:length(files.v)){
  beep("coin")
  for(ch in 1:length(CH_inst.v)){
    if(!is.na(CH_inst.a[book,ch])){
      start<-NA
      start <- CH_inst.a[book,ch]+2
        if(!is.na(CH_inst.a[book,(ch+1)])){
        end<-NA
        end <- CH_inst.a[book, (ch+1)]-1
        }else{
        end<-NA
        end <- length(my.corpus.l[[book]])
        }  
    }else{break()}
  #@ at this point we should have the start and end of the chapter of interest
    chapters.a[1,ch,book] <- files.v[book]
    chapters.a[2,ch,book] <- paste("ch", ch, sep="_")
    holder <- NA
    holder <- my.corpus.l[[book]][start:(end)]
    ch_contents <- NA
    ch_contents <- paste (holder, collapse=" ")
    chapters.a[3,ch,book] <- ch_contents
  }}
beep("complete")

#@ test to make sure the object was created correctly
#@ (the indexing here avoids printing chapter contents, which will fill the console!)
chapters.a[1:2,1:3,1:2]
#@ see [book and chapter (NOT chapter contents), for first 3 chapters, for first 2 books]
## if you WANT to see a chapter (first one first book), use this:    _  chapters.a[3,1,1]







########################################################################
############################# isolate Disag Bag of Words contents  #####
### here we are "chunking out" bags of words based on the above ########
## this is almost the same loop as above, with a few small differences #
########################################################################
########################################################################

CH_id.v <- c("book", "ch#", "CHtext")
CH_inst.v  #@ (again, re-using this) - expected greatest # chapters/book
files.v    #@ (again, the vector of book titles)
disag.a <- array(NA,    ## this new data object will store disaggregated contents
                    dim=c(length(CH_id.v), length(CH_inst.v), length(files.v)),
                    dimnames=list(CH_id.v, CH_inst.v, files.v))

####### The loop to isolate and capture bags of words per chapter
for(book in 1:length(files.v)){
  beep("coin")
  for(ch in 1:length(CH_inst.v)){
    if(!is.na(CH_inst.a[book,ch])){
      start<-NA
      start <- CH_inst.a[book,ch]+2
      if(!is.na(CH_inst.a[book,(ch+1)])){
        end<-NA
        end <- CH_inst.a[book, (ch+1)]
      }else{
        end<-NA
        end <- length(my.corpus.l[[book]])
      }  
    }else{break()}
    #@ at this point we should have the start and end of the chapter of interest
    disag.a[1,ch,book] <- files.v[book]
    disag.a[2,ch,book] <- paste("_ch_", ch)
    holder <- NA
    holder <- my.corpus.l[[book]][start:(end-1)]
    low_holder <- tolower(holder)
    alpha_holder <- sort(low_holder)
    disag_contents <- NA
    disag_contents <- paste (alpha_holder, collapse=" ")
    disag.a[3,ch,book] <- disag_contents
  }}
beep("complete")

disag.a[1:2,1:3,1:2]   #@ same indexing above; this should look identical
## if you WANT to see a bag of words (again, 1st book 1st chapter) :
####                                                    _    disag.a[3,1,1]





########################################################################
########################################################################
######################## change 3d arrays to printable 2d matrices  ####
########################################################################
########################################################################
# 3d arrays initially used because they are more flexible for capturing 3-dimensional data
# however, 2d matricies are needed if we want to print out a .csv
# file giving each book/chapter's name and its corresponding bag of words
# either would work for printing individual chapter bag of words files,
# we just do both using the 2d matrix for convenience


#@ the 3D Arrays we draw from (created above_:
#     chapters.a
#     disag.a

#@ 2D chapter matricies, listing book title and chapter # as a single string:
d2.chapters.a <- c("Book Title + Chapter #", "Consumable Content")
names(d2.chapters.a) <- c("Book+ch", "text")
d2.disag.a <- c("Book Title + Chapter #", "Disag Bag of Words")
names(d2.disag.a) <- c("Book+ch", "text")              


#@ Filling out those 2d matrices 
for(book in 1:length(files.v)){
  beep("coin")
  for(ch in 1:length(CH_inst.v)){
    if(!is.na(chapters.a[1,ch,book])){
      ch.holder <- NA
      ch.holder <- chapters.a[,ch,book]
      ch.holdera <- c(paste(ch.holder[1],ch.holder[2], sep="_"), ch.holder[3])
      d2.chapters.a <- rbind(d2.chapters.a, ch.holdera[])
    }
    if(!is.na(disag.a[1,ch,book])){
      dg.holder <- NA
      dg.holder <- disag.a[,ch,book]
      dg.holdera <- c(paste(dg.holder[1],dg.holder[2], sep="_"), dg.holder[3])
      d2.disag.a <- rbind(d2.disag.a, dg.holdera[])
    }
  }}
beep("complete")

#@ a good way to check that everythign worked correctly; ensure the dimensions are the same
dim(d2.chapters.a); dim(d2.disag.a)
d2.chapters.a[1:5,1]  # this give the first 5 entries of the book+chapter# data



########################################################################
########################################################################
######################## Write the Outputs! Both matrices and BOWs  ####
########################################################################
########################################################################

matrix.dir <- "/matrix_output"

setwd(paste(proj.dir,matrix.dir, sep=""))
#write.csv(d2.chapters.a, "Corpus_Chapters_Consumable.csv", row.names=F)
write.csv(d2.disag.a,    "Corpus_ExtractedFeatures_BagsOfWords.csv", row.names=F)

BoW.dir <- "/bags_of_words"
setwd(paste(proj.dir, BoW.dir, sep=""))

setwd(paste(project.dir, BoW.dir, sep=""))
for(book_ch in 2:nrow(d2.disag.a)){
write.table(d2.disag.a[book_ch,2], file=paste(d2.disag.a[book_ch, 1],"_ExtFeat.txt",sep=""))}






########################################################################
########################################################################
######################## Ending here; Trial Code is below!          ####
########################################################################
########################################################################